package br.mat.mmgalvao.aleph.dbserver.interfaces;

import javax.ejb.Remote;

@Remote
public interface DbServerRemote extends DbServerGeneric {}


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\aleph\dbserver\interfaces\DbServerRemote.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */