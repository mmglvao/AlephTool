/*     */ package br.mat.mmgalvao.aleph.dbserver;
/*     */ 
/*     */ import br.mat.mmgalvao.aleph.dbserver.interfaces.DbServerRemote;
/*     */ import br.mat.mmgalvao.common.aleph.DataSet;
/*     */ import br.mat.mmgalvao.common.aleph.dao.DbServerDAO;
/*     */ import java.sql.Connection;
/*     */ import java.util.HashMap;
/*     */ import javax.ejb.Remove;
/*     */ import javax.ejb.Stateful;
/*     */ import javax.naming.InitialContext;
/*     */ import javax.naming.NamingException;
/*     */ import javax.sql.DataSource;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ @Stateful(mappedName = "DbServer")
/*     */ public class DbServer
/*     */   implements DbServerRemote
/*     */ {
/*  27 */   static HashMap<String, DataSource> maps = new HashMap<>();
/*  28 */   DbServerDAO dao = null;
/*  29 */   static int count = 0;
/*     */ 
/*     */ 
/*     */   
/*     */   public void crateConnection(String datasource) {
/*     */     try {
/*  35 */       if (this.dao == null) {
/*  36 */         DataSource ds = getDataSource1(datasource);
/*  37 */         Connection con = ds.getConnection();
/*  38 */         this.dao = new DbServerDAO(con);
/*     */       }
/*     */     
/*     */     }
/*  42 */     catch (Throwable ex) {
/*  43 */       throw new RuntimeException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) {
/*  56 */     DataSet ds1 = this.dao.getTables(catalog, schemaPattern, tableNamePattern, types);
/*  57 */     return ds1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSet getImportedKeys(String catalog, String schema, String table) {
/*  68 */     DataSet ds1 = this.dao.getImportedKeys(catalog, schema, table);
/*  69 */     return ds1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSet getExportedKeys(String catalog, String schema, String table) {
/*  79 */     DataSet ds1 = this.dao.getExportedKeys(catalog, schema, table);
/*  80 */     return ds1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSet getIndexInfo(String datasource, String catalog, String schema, String table, boolean unique, boolean approximate) {
/*  89 */     DataSet ds1 = this.dao.getIndexInfo(catalog, schema, table, unique, approximate);
/*  90 */     return ds1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static DataSource getDataSource1(String resourceName) throws NamingException {
/* 102 */     System.out.println("criei novo");
/* 103 */     InitialContext ctx = new InitialContext();
/*     */ 
/*     */     
/* 106 */     DataSource ds = (DataSource)ctx.lookup(resourceName);
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 111 */     return ds;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public DataSet execute(String query, Object[] params) {
/* 119 */     DataSet ds1 = this.dao.execute(query, params);
/* 120 */     return ds1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public String getDatabaseProductVersion() {
/* 126 */     return this.dao.getDatabaseProductVersion();
/*     */   }
/*     */ 
/*     */   
/*     */   public String getDatabaseProductName() {
/* 131 */     return this.dao.getDatabaseProductName();
/*     */   }
/*     */   
/*     */   @Remove(retainIfException = false)
/*     */   public void close() {
/* 136 */     this.dao.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public DataSet getColumns(String cat, String schema, String table, String col) {
/* 141 */     return this.dao.getColumns(cat, schema, table, col);
/*     */   }
/*     */ }


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\aleph\dbserver\DbServer.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */