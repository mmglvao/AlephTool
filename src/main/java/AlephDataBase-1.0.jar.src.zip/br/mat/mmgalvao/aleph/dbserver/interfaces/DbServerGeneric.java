package br.mat.mmgalvao.aleph.dbserver.interfaces;

import br.mat.mmgalvao.common.aleph.DataSet;

public interface DbServerGeneric {
  void crateConnection(String paramString);
  
  DataSet getTables(String paramString1, String paramString2, String paramString3, String[] paramArrayOfString);
  
  String getDatabaseProductVersion();
  
  String getDatabaseProductName();
  
  DataSet getImportedKeys(String paramString1, String paramString2, String paramString3);
  
  DataSet getColumns(String paramString1, String paramString2, String paramString3, String paramString4);
  
  DataSet execute(String paramString, Object... paramVarArgs);
  
  DataSet getExportedKeys(String paramString1, String paramString2, String paramString3);
  
  DataSet getIndexInfo(String paramString1, String paramString2, String paramString3, String paramString4, boolean paramBoolean1, boolean paramBoolean2);
  
  void close();
}


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\aleph\dbserver\interfaces\DbServerGeneric.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */