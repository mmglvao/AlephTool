package br.mat.mmgalvao.common.aleph;

public class ColumnInfo extends Column {
  String dataType;
}


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\common\aleph\ColumnInfo.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */