/*     */ package br.mat.mmgalvao.common.aleph;
/*     */ import java.sql.Date;
/*     */ import java.util.HashMap;
/*     */ 
/*     */ public class DataSet implements Serializable {
/*     */   private static final long serialVersionUID = 1L;
/*     */   boolean sucess;
/*     */   String errorMessage;
/*   9 */   int postAtual = -1; int errorCode;
/*     */   public int getPosAtual() {
/*  11 */     return this.postAtual;
/*     */   } Column[] columns;
/*     */   public void reset() {
/*  14 */     this.postAtual = -1;
/*     */   }
/*     */   public String toString() {
/*  17 */     String str = "";
/*     */     
/*  19 */     for (Object[] str1 : this.data) {
/*  20 */       int i = 0;
/*  21 */       for (Column col : this.columns)
/*     */       {
/*  23 */         str = str + col.getName() + "=" + String.valueOf(str1[i++]) + "\n";
/*     */       }
/*     */       
/*  26 */       str = str + "\n";
/*     */       
/*  28 */       str = str + "--------------------\n";
/*     */     } 
/*  30 */     return str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   HashMap<String, Integer> campos = new HashMap<>(); Object[][] data;
/*     */   
/*     */   public Column[] getColumns() {
/*  41 */     return this.columns;
/*     */   }
/*     */   
/*     */   public void setColumns(Column[] collumns) {
/*  45 */     this.columns = collumns;
/*  46 */     createRefs();
/*     */   }
/*     */   public void createRefs() {
/*  49 */     int i = 0;
/*     */     
/*  51 */     for (Column col : this.columns)
/*     */     {
/*  53 */       this.campos.put(col.getName().toLowerCase(), Integer.valueOf(i++)); } 
/*     */   }
/*     */   
/*     */   public Object getValue(int i) {
/*  57 */     return this.data[this.postAtual][i];
/*     */   }
/*     */   public Integer getIntValue(int i) {
/*  60 */     Object s = getValue(i);
/*  61 */     if (s == null) return null; 
/*  62 */     if (s instanceof Number) {
/*  63 */       return Integer.valueOf(((Number)s).intValue());
/*     */     }
/*  65 */     throw new RuntimeException("tipo nao é numerico");
/*     */   }
/*     */   
/*     */   public Long getLongValue(int i) {
/*  69 */     Object s = getValue(i);
/*  70 */     if (s == null) return null; 
/*  71 */     if (s instanceof Number) {
/*  72 */       return Long.valueOf(((Number)s).longValue());
/*     */     }
/*  74 */     throw new RuntimeException("tipo nao é numerico");
/*     */   }
/*     */   
/*     */   public Double getDoubleValue(int i) {
/*  78 */     Object s = getValue(i);
/*  79 */     if (s == null) return null; 
/*  80 */     if (s instanceof Number) {
/*  81 */       return Double.valueOf(((Number)s).doubleValue());
/*     */     }
/*  83 */     throw new RuntimeException("tipo nao é numerico");
/*     */   }
/*     */   
/*     */   public Date getDateValue(int i) {
/*  87 */     Object s = getValue(i);
/*  88 */     if (s == null) return null; 
/*  89 */     if (s instanceof Date) {
/*  90 */       return (Date)s;
/*     */     }
/*  92 */     throw new RuntimeException("tipo nao é date");
/*     */   }
/*     */   public String getStringValue(int i) {
/*  95 */     Object s = getValue(i);
/*  96 */     if (s == null) return null; 
/*  97 */     if (s instanceof String) {
/*  98 */       return (String)s;
/*     */     }
/* 100 */     throw new RuntimeException("tipo nao é string");
/*     */   }
/*     */   public Boolean getBoleanValue(int i) {
/* 103 */     Object s = getValue(i);
/* 104 */     if (s == null) return null; 
/* 105 */     if (s instanceof Boolean) {
/* 106 */       return Boolean.valueOf(((Boolean)s).booleanValue());
/*     */     }
/* 108 */     throw new RuntimeException("tipo nao é boolean");
/*     */   }
/*     */   public Object getValue(String name) {
/* 111 */     Integer s = this.campos.get(name.toLowerCase());
/* 112 */     if (s != null) {
/* 113 */       return getValue(s.intValue());
/*     */     }
/* 115 */     throw new RuntimeException("Field not find  " + name);
/*     */   }
/*     */   
/*     */   public Long getLongValue(String i) {
/* 119 */     Object s = getValue(i);
/* 120 */     if (s == null) return null; 
/* 121 */     if (s instanceof Number) {
/* 122 */       return Long.valueOf(((Number)s).longValue());
/*     */     }
/* 124 */     throw new RuntimeException("tipo nao é numerico");
/*     */   }
/*     */   
/*     */   public Double getDoubleValue(String i) {
/* 128 */     Object s = getValue(i);
/* 129 */     if (s == null) return null; 
/* 130 */     if (s instanceof Number) {
/* 131 */       return Double.valueOf(((Number)s).doubleValue());
/*     */     }
/* 133 */     throw new RuntimeException("tipo nao é numerico");
/*     */   }
/*     */   
/*     */   public Date getDateValue(String i) {
/* 137 */     Object s = getValue(i);
/* 138 */     if (s == null) return null; 
/* 139 */     if (s instanceof Date) {
/* 140 */       return (Date)s;
/*     */     }
/* 142 */     throw new RuntimeException("tipo nao é date");
/*     */   }
/*     */   public String getStringValue(String i) {
/* 145 */     Object s = getValue(i);
/* 146 */     if (s == null) return null; 
/* 147 */     if (s instanceof String) {
/* 148 */       return (String)s;
/*     */     }
/* 150 */     throw new RuntimeException("tipo nao é string");
/*     */   }
/*     */   public Boolean getBoleanValue(String i) {
/* 153 */     Object s = getValue(i);
/* 154 */     if (s == null) return null; 
/* 155 */     if (s instanceof Boolean) {
/* 156 */       return Boolean.valueOf(((Boolean)s).booleanValue());
/*     */     }
/* 158 */     throw new RuntimeException("tipo nao é boolean");
/*     */   }
/*     */   
/*     */   public Object[][] getData() {
/* 162 */     return this.data;
/*     */   }
/*     */   
/*     */   public void setData(Object[][] data) {
/* 166 */     this.data = data;
/*     */   }
/*     */   public boolean isSucess() {
/* 169 */     return this.sucess;
/*     */   }
/*     */   public void setSucess(boolean sucess) {
/* 172 */     this.sucess = sucess;
/*     */   }
/*     */   public String getErrorMessage() {
/* 175 */     return this.errorMessage;
/*     */   }
/*     */   public void setErrorMessage(String errorMessage) {
/* 178 */     this.errorMessage = errorMessage;
/*     */   }
/*     */   public int getErrorCode() {
/* 181 */     return this.errorCode;
/*     */   }
/*     */   public void setErrorCode(int errorCode) {
/* 184 */     this.errorCode = errorCode;
/*     */   }
/*     */   
/*     */   public boolean next() {
/* 188 */     if (this.postAtual < (getData()).length - 1) {
/* 189 */       if (this.campos == null || this.campos.size() == 0) {
/* 190 */         if (this.campos == null) this.campos = new HashMap<>(); 
/* 191 */         createRefs();
/*     */       } 
/* 193 */       this.postAtual++;
/*     */       
/* 195 */       return true;
/*     */     } 
/* 197 */     return false;
/*     */   }
/*     */ }


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\common\aleph\DataSet.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */