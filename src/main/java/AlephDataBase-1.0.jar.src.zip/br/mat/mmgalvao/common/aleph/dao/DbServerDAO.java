/*     */ package br.mat.mmgalvao.common.aleph.dao;
/*     */ 
/*     */ import br.mat.mmgalvao.common.aleph.Column;
/*     */ import br.mat.mmgalvao.common.aleph.ColumnInfo;
/*     */ import br.mat.mmgalvao.common.aleph.DataSet;
/*     */ import java.io.UnsupportedEncodingException;
/*     */ import java.math.BigInteger;
/*     */ import java.sql.Connection;
/*     */ import java.sql.DatabaseMetaData;
/*     */ import java.sql.DriverManager;
/*     */ import java.sql.PreparedStatement;
/*     */ import java.sql.ResultSet;
/*     */ import java.sql.ResultSetMetaData;
/*     */ import java.sql.SQLException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.logging.Level;
/*     */ import java.util.logging.Logger;
/*     */ 
/*     */ 
/*     */ public class DbServerDAO
/*     */ {
/*  23 */   DatabaseMetaData metada = null;
/*     */   public DbServerDAO(Connection con) {
/*  25 */     this.con = con;
/*     */     try {
/*  27 */       this.metada = con.getMetaData();
/*  28 */     } catch (SQLException ex) {
/*  29 */       Logger.getLogger(DbServerDAO.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   Connection con;
/*     */   public String getDatabaseProductName() {
/*     */     try {
/*  35 */       return this.metada.getDatabaseProductName();
/*     */     }
/*  37 */     catch (SQLException ex) {
/*  38 */       ex.printStackTrace();
/*  39 */       throw new RuntimeException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public String getDatabaseProductVersion() {
/*     */     try {
/*  45 */       return this.metada.getDatabaseProductVersion();
/*     */     }
/*  47 */     catch (SQLException ex) {
/*  48 */       ex.printStackTrace();
/*  49 */       throw new RuntimeException(ex.getMessage(), ex);
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataSet getTables(String catalog, String schemaPattern, String tableNamePattern, String[] types) {
/*  54 */     DataSet dt = new DataSet();
/*     */     
/*     */     try {
/*  57 */       getData(this.metada.getTables(catalog, schemaPattern, tableNamePattern, types), dt);
/*  58 */       return dt;
/*     */     }
/*  60 */     catch (SQLException sqle) {
/*     */ 
/*     */ 
/*     */       
/*  64 */       System.out.println(String.valueOf(sqle.getErrorCode()));
/*  65 */       System.out.println(sqle.getMessage());
/*  66 */       dt.setSucess(false);
/*  67 */       dt.setErrorCode(sqle.getErrorCode());
/*     */ 
/*     */       
/*  70 */       return dt;
/*     */     } 
/*     */   } public DataSet getImportedKeys(String catalog, String schema, String table) {
/*  73 */     DataSet dt = new DataSet();
/*     */     
/*     */     try {
/*  76 */       getData(this.metada.getImportedKeys(catalog, schema, table), dt);
/*  77 */       return dt;
/*     */     }
/*  79 */     catch (SQLException sqle) {
/*     */ 
/*     */ 
/*     */       
/*  83 */       System.out.println(String.valueOf(sqle.getErrorCode()));
/*  84 */       System.out.println(sqle.getMessage());
/*  85 */       dt.setSucess(false);
/*  86 */       dt.setErrorCode(sqle.getErrorCode());
/*     */ 
/*     */       
/*  89 */       return dt;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public DataSet getColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern) {
/*  95 */     DataSet dt = new DataSet();
/*     */     
/*     */     try {
/*  98 */       getData(this.metada.getColumns(catalog, schemaPattern, tableNamePattern, columnNamePattern), dt);
/*  99 */       return dt;
/*     */     }
/* 101 */     catch (SQLException sqle) {
/*     */ 
/*     */ 
/*     */       
/* 105 */       System.out.println(String.valueOf(sqle.getErrorCode()));
/* 106 */       System.out.println(sqle.getMessage());
/* 107 */       dt.setSucess(false);
/* 108 */       dt.setErrorCode(sqle.getErrorCode());
/*     */ 
/*     */       
/* 111 */       return dt;
/*     */     } 
/*     */   }
/*     */   public DataSet getExportedKeys(String catalog, String schema, String table) {
/* 115 */     DataSet dt = new DataSet();
/*     */     
/*     */     try {
/* 118 */       getData(this.metada.getExportedKeys(catalog, schema, table), dt);
/*     */     
/*     */     }
/* 121 */     catch (SQLException sqle) {
/*     */ 
/*     */       
/* 124 */       sqle.printStackTrace();
/* 125 */       System.out.println(String.valueOf(sqle.getErrorCode()));
/* 126 */       System.out.println(sqle.getMessage());
/* 127 */       dt.setSucess(false);
/* 128 */       dt.setErrorCode(sqle.getErrorCode());
/*     */     } 
/*     */     
/* 131 */     return dt;
/*     */   }
/*     */   
/*     */   public DataSet getIndexInfo(String catalog, String schema, String table, boolean unique, boolean approximate) {
/* 135 */     DataSet dt = new DataSet();
/*     */     
/*     */     try {
/* 138 */       getData(this.metada.getIndexInfo(catalog, schema, table, unique, approximate), dt);
/*     */     
/*     */     }
/* 141 */     catch (SQLException sqle) {
/*     */ 
/*     */ 
/*     */       
/* 145 */       System.out.println(String.valueOf(sqle.getErrorCode()));
/* 146 */       System.out.println(sqle.getMessage());
/* 147 */       dt.setSucess(false);
/* 148 */       dt.setErrorCode(sqle.getErrorCode());
/*     */     } 
/*     */     
/* 151 */     return dt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 160 */       if (this.con != null)
/*     */       {
/* 162 */         this.con.close();
/* 163 */         System.out.println("Closed");
/* 164 */         this.con = null;
/*     */       }
/*     */     
/* 167 */     } catch (SQLException ex) {
/* 168 */       Logger.getLogger(DbServerDAO.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */     } 
/*     */   }
/*     */   public List<ColumnInfo> getMetadataTable(String db, String schema, String table) throws SQLException {
/* 172 */     List<ColumnInfo> result = new ArrayList<>();
/* 173 */     ResultSet rs = this.con.getMetaData().getColumns(db, schema, table, "%");
/*     */ 
/*     */ 
/*     */     
/* 177 */     getCollumnInfo(rs, result);
/* 178 */     return result;
/*     */   }
/*     */   private void getCollumnInfo(ResultSet rs, List<ColumnInfo> result) throws SQLException {
/* 181 */     while (rs.next()) {
/* 182 */       result.add(analiseColmun(rs, result));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private ColumnInfo analiseColmun(ResultSet rs, List<ColumnInfo> result) {
/* 188 */     return null;
/*     */   }
/*     */   
/*     */   public DataSet execute(String query, Object... params) {
/* 192 */     DataSet dt = new DataSet();
/* 193 */     PreparedStatement st = null;
/*     */     try {
/* 195 */       System.out.println(query);
/* 196 */       st = this.con.prepareCall(query);
/* 197 */       createParams(st, params);
/* 198 */       if (st.execute()) {
/* 199 */         getData(st.getResultSet(), dt);
/*     */       }
/* 201 */       dt.setSucess(true);
/*     */     
/*     */     }
/* 204 */     catch (SQLException sqle) {
/*     */       
/* 206 */       System.out.println(String.valueOf(sqle.getErrorCode()) + query);
/* 207 */       System.out.println(sqle.getMessage());
/* 208 */       dt.setSucess(false);
/* 209 */       dt.setErrorCode(sqle.getErrorCode());
/*     */     } finally {
/*     */       
/*     */       try {
/* 213 */         if (st.getResultSet() != null)
/*     */         {
/* 215 */           st.getResultSet().close();
/*     */         }
/*     */ 
/*     */         
/* 219 */         st.close();
/* 220 */       } catch (SQLException ex) {
/* 221 */         Logger.getLogger(DbServerDAO.class.getName()).log(Level.SEVERE, (String)null, ex);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 226 */     return dt;
/*     */   }
/*     */   
/*     */   private void createParams(PreparedStatement st, Object[] params) throws SQLException {
/* 230 */     int i = 1;
/* 231 */     for (Object p : params) {
/* 232 */       st.setObject(i++, p);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void getData(ResultSet rs, DataSet dt) throws SQLException {
/* 240 */     getMetadata(rs.getMetaData(), dt);
/* 241 */     getData(rs, rs.getMetaData(), dt);
/*     */   }
/*     */ 
/*     */   
/*     */   private void getMetadata(ResultSetMetaData metaData, DataSet dt) throws SQLException {
/* 246 */     Column[] columns = new Column[metaData.getColumnCount()];
/* 247 */     for (int i = 1; i <= metaData.getColumnCount(); i++) {
/* 248 */       columns[i - 1] = crateColumnInfo(metaData, i);
/*     */     }
/* 250 */     dt.setColumns(columns);
/*     */   }
/*     */   
/*     */   private Column crateColumnInfo(ResultSetMetaData d, int i) throws SQLException {
/* 254 */     Column col = new Column();
/* 255 */     col.setNullAble(d.isNullable(i));
/* 256 */     col.setPrecsion(d.getPrecision(i));
/* 257 */     col.setScale(d.getScale(i));
/* 258 */     col.setPos(i);
/* 259 */     col.setMaxLength(d.getColumnDisplaySize(i));
/* 260 */     col.setName(d.getColumnName(i));
/* 261 */     col.setTypeName(d.getColumnClassName(i));
/* 262 */     return col;
/*     */   }
/*     */ 
/*     */   
/*     */   private void getData(ResultSet rs, ResultSetMetaData d, DataSet dt) throws SQLException {
/* 267 */     List<Object[]> ls = new ArrayList();
/*     */     
/* 269 */     while (rs.next()) {
/* 270 */       Object[] ls1 = new Object[d.getColumnCount()];
/* 271 */       for (int i = 1; i <= d.getColumnCount(); i++) {
/* 272 */         Object obj = rs.getObject(i);
/* 273 */         if (obj instanceof String) {
/* 274 */           String str1 = (String)obj;
/* 275 */           obj = str1.trim();
/* 276 */           if (str1.startsWith("!#SERIAL#!")) {
/* 277 */             int l = "!#SERIAL#!       2164800000000000000014E490000000000000002430000000000000050".length();
/*     */             try {
/* 279 */               obj = (new String((new BigInteger(str1.substring(l), 16)).toByteArray(), "ISO-8859-1")).trim();
/* 280 */             } catch (UnsupportedEncodingException e) {
/*     */               
/* 282 */               e.printStackTrace();
/*     */             } 
/*     */           } 
/*     */         } 
/*     */ 
/*     */         
/* 288 */         ls1[i - 1] = obj;
/*     */       } 
/* 290 */       ls.add(ls1);
/*     */     } 
/*     */     
/* 293 */     dt.setData(ls.<Object[]>toArray(new Object[0][]));
/*     */   }
/*     */   
/*     */   public static void main(String[] args) throws SQLException {
/* 297 */     Connection conn = null;
/* 298 */     ResultSet rs = null;
/* 299 */     String url = "jdbc:sqlserver://127.0.0.1:1433;database=Desenv_RH";
/* 300 */     String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
/* 301 */     String userName = "sa";
/* 302 */     String password = "gabi3010"; try {
/* 303 */       Class.forName(driver);
/* 304 */       conn = DriverManager.getConnection(url, userName, password);
/*     */       
/* 306 */       DbServerDAO dao = new DbServerDAO(conn);
/* 307 */       System.out.println(dao.getExportedKeys("Desenv_RH", "dbo", "USUARIOS"));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     }
/* 348 */     catch (SQLException e) {
/* 349 */       System.out.println(e.getErrorCode());
/* 350 */       System.out.println(e.getMessage());
/*     */     
/*     */     }
/* 353 */     catch (Exception ex) {
/* 354 */       ex.printStackTrace();
/*     */     } 
/*     */     
/* 357 */     if (conn != null) {
/* 358 */       conn.close();
/* 359 */       if (rs != null)
/* 360 */         rs.close(); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              C:\Users\Mauricio\Downloads\AlephDataBase-1.0.jar!\br\mat\mmgalvao\common\aleph\dao\DbServerDAO.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       1.1.3
 */